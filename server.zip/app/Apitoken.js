
module.exports ={
    apitoken : "eee8efe1-4f77-4dc4-96e7-4d3afc0fedbe"
}