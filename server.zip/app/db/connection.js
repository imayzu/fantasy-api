const mysql = require("mysql");
const config = {
	host: '127.0.0.1',
	user: 'root',
	password: 'root',
	database: 'cricket_match'
};

const mysql_connection = mysql.createConnection(config);

mysql_connection.connect((err) => {
	if (!err) {
		console.log("database connection created ");
	} else {
		console.log("connection failed");
	}
});

module.exports = mysql_connection;

