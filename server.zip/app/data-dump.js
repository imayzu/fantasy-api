const { MongoClient } = require('mongodb');


const url = 'mongodb+srv://lmjportal:K9sFYFNu8K9aGo8N@lmj-portal.t0tij.mongodb.net/1005_saas_db_dev_1002?retryWrites=true&w=majority';
const client = new MongoClient(url);


const dbName = '1005_saas_db_dev_1002';

async function main() {

    await client.connect();
    console.log('Connected successfully to server');
    const db = client.db(dbName);
    const collection = db.collection('documents');
   console.log(collection)

    return 'done.';
}

main()
    .then(console.log)
    .catch(console.error)
    .finally(() => client.close());