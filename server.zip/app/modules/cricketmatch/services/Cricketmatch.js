const {reject} = require("bcrypt/promises");
const axios = require('axios');
const API_ACCESS = require('../../../Apitoken.js')
let {apitoken} = API_ACCESS;
const jwt = require('jsonwebtoken');
let secret = "this-is-cricket-match"
let expireTime = "70000d"
const Cricketmatch = {};


Cricketmatch.getUpcomingMatches = async()=>{
    try {

        let {data }= await axios.get(`https://api.cricapi.com/v1/matches?apikey=${apitoken}&offset=0`)
        let result = data.data || [];
        return  result;
    }catch (e) {
        return e;
    }

}
Cricketmatch.getNotStartedMatches = async()=>{
    try {
        let {data }= await axios.get(`https://api.cricapi.com/v1/matches?apikey=${apitoken}&offset=0`)
        let result = data.data || [];
         result = result.filter(item => item.status ==  "Match not started");
        return  result;
    }catch (e) {
        return e;
    }

}
Cricketmatch.getCompletedMatches = async(matchId)=>{
    try {

        let {data }= await axios.get(`https://api.cricapi.com/v1/currentMatches?apikey=${apitoken}&offset=0`)
        let result = data.data || [];
        if(!!matchId){
            result = result.filter(item => item.id == matchId );
        }else {
            result = result.filter(item => item.matchEnded === true);
        }

        return  result;
    }catch (e) {
        return e;
    }

}
Cricketmatch.livedMatches = async()=>{
    try {
        let {data }= await axios.get(`https://api.cricapi.com/v1/currentMatches?apikey=${apitoken}&offset=0`)
        let result = data.data || [];
         result = result.filter(item => item.matchEnded === false);
        return  result;
    }catch (e) {
        return e;
    }

}
Cricketmatch.getAllSeries = async (search)=>{
    try {
        let apiPoint;
        if(!!search){
            apiPoint = `https://api.cricapi.com/v1/currentMatches?apikey=${apitoken}&offset=0&search=${search}`
        }else{
            apiPoint = `https://api.cricapi.com/v1/currentMatches?apikey=${apitoken}&offset=0`
        }
        let {data }= await axios.get(apiPoint)
        let result = data.data || [];
        return  result;
    }catch (e){
        return e;
    }
}
Cricketmatch.getAllMatchInfo = async (seriesId)=>{
 try {
     let {data }= await axios.post(`https://api.cricapi.com/v1/match_info?apikey=${apitoken}&offset=0&id=${seriesId}`)
     let result = data.data || [];
     return  result;
 }catch (e){
     return e;
 }

}
Cricketmatch.getPlayerInfo = async (playerId) =>{
    try {

        let {data }= await axios.post(`https://api.cricapi.com/v1/players_info?apikey=${apitoken}&id=${playerId}`)
        let result = data.data || [];
        return  result;
    }catch (e){
        return e;
    }

};
Cricketmatch.SearchPlayer = async (Search)=>{
    try {
        if(!!Search){
            let {data} = await axios.post(`https://api.cricapi.com/v1/players?apikey=${apitoken}&offset=0&search=${Search}`)
            let result = data.data || [];
            return  result;
        }
        return [];

    }catch (e){
        return e;
    }
}
Cricketmatch.getPlayerElevens = async (matchId) =>{
    try {
        if(!!matchId){
          let data = await axios.post(`https://api.cricapi.com/v1/match_xi?apikey=${apitoken}&id=${matchId}`)
            let result = data.data || [];
            return  result;
        }
        return  [];
    }catch (e){
        return e;
    }
}
Cricketmatch.getBallBYBallInfo =  async (matchId)=>{
    try {
    if(!!matchId){
        let {data} = await axios.post(`https://api.cricapi.com/v1/match_points?apikey=${apitoken}
&offset=0&id=${matchId}`)
        let result = data.data || [];
        return  result;
    }
    return  [];
    }catch (e){
        return e;
    }
}
Cricketmatch.getSquadList =  async (matchId)=>{
    try {
        if(!!matchId){
            let {data} = await axios.post(`https://api.cricapi.com/v1/match_squad?apikey=${apitoken}&offset=0&id=${matchId}`)
            let result = data.data || [];
            return  result;
        }
        return  [];
    }catch (e){
        return e;
    }
}

module.exports = Cricketmatch;
