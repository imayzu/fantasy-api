const axios = require("axios");

module.exports ={
    apitoken : "eee8efe1-4f77-4dc4-96e7-4d3afc0fedbe",
    changeToken:  async  function (isChange){
        let apitoken = "a9a9b9ca-871c-471e-a6b4-9f582a1d2f3e";
        if(isChange == true) {
            let tokens = [
                'c3cea3b9-75c8-401b-b1d3-ad9d51d9f2f4',
                'a8432f23-b00a-4b17-85a0-6a326972a717',
                '863284dc-2a5b-4936-b478-06b430818a45',
                '33f6ae8f-4442-48a1-aeae-4ce8071cb2b1',
                '5c92a05d-a025-4474-a933-71d4a73c8fb3',
                '3921aaea-08d0-4969-ab0e-1f1d485339b3',
                '04b96eaa-12f8-408e-8630-5fed30203d85',
                'eaa9b99a-8bd0-4a45-b47f-572f70e92597',
                '64dd0e6b-4d68-4d63-a6f5-a59acc39bb93',
                '94f2d9f6-b302-43da-b1f1-597d404872c6',
                '8be59476-7551-47c2-b6c1-0ac3b9124ee5',
                'ab3599fe-9790-415d-89b7-9099a6acb785',
                '4c84c3d9-4551-4405-9bb1-e63262c57190',
                'ed157ce4-74cd-4819-9daf-ff9d9b7ecf96',
                '026742de-c397-4b76-996b-455e8256fc5b',
                '78b973e8-09a7-489a-87de-e2c08d167ddf',
                'a68d5bf3-ae97-4c5a-ac5a-b3a31baf8fef',
                'e77ff183-e48a-4590-8519-a008e853089b',
                '90566466-b9be-4f1f-bce1-4713ae51f2c4',
                'e200a32f-d574-4628-a788-5042335c8aa4',
                'e018b8dd-7fad-42e8-92e7-8b205b8a9e54',
                'c9ce0afb-10ef-43f0-8f06-d22cdd1d9b21',
                'f05e2667-a141-4fd2-b044-b888098c28ba',
                '23164048-3e5d-42a9-8892-6dba84eda2f8',
                '4d693aea-f232-4b57-bc7f-c99c852814ee',
                '2f2a8d06-d282-4515-8641-e8489fb58317',
                '778a1cec-013f-4e89-bc19-f9645e26fefd',
                '4279155f-dd6e-40b8-b0f6-c246cd9bc8cc',
                '6bd2939f-7e82-471d-bb35-f9139d1a2f10',
                '53b72706-59f9-4df3-809a-0b4a8346088c',
                'eb67d86b-8a83-4729-b0a9-ac4c96048744',
                'd768aad0-af35-4da9-b7cb-ae638d4a8932',
                'f763b43b-3642-429c-9469-df401e1ed329',
                '6841dfdd-f105-4a08-9418-c044a4d5dda8',
                '03c8e990-2dd6-4e7b-b0fa-5892335b2d3e',
                '5fddb400-6faa-4687-a69d-67faa39a99e0',
                '49db3a3f-dc56-4285-92b8-8915a4b3e570',
                '71fa5ebf-3a63-4043-b06d-3efe838f9332',
                '52c33ec9-5acc-470a-9563-7c22bde6ba06',


            ]
            let value = tokens.pop();
                return value
        }else{
            return  apitoken;
        }
    },





}