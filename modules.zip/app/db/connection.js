const mysql = require("mysql");
const config = {
	host: 'd09.h.filess.io',
	user: 'fantasyapi_settlersam',
	password: 'b2b62912b0bcb1979a037a386cdd14c77423bf7d',
	database: 'fantasyapi_settlersam',
	port: '3305'
};

const mysql_connection = mysql.createConnection(config);

mysql_connection.connect((err) => {
	if (!err) {
		console.log("database connection created ");
	} else {
		console.log("connection failed");
	}
});

module.exports = mysql_connection;

